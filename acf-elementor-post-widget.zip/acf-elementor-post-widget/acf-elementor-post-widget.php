<?php
/**
 * Plugin Name: ACF Elementor Post Widget
 * Description: Elementor widget to display Post Title and ACF Field with design controls.
 * Version: 1.0
 * Author: Akima
 */

if (!defined('ABSPATH')) exit;

function aepw_register_widgets($widgets_manager){

require_once(__DIR__.'/widgets/acf-post-widget.php');

$widgets_manager->register(new \AEPW_Post_Widget());

}

add_action('elementor/widgets/register','aepw_register_widgets');