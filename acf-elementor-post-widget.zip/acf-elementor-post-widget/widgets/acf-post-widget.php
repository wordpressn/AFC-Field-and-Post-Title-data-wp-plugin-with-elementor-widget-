<?php

if (!defined('ABSPATH')) exit;

class AEPW_Post_Widget extends \Elementor\Widget_Base {

public function get_name(){
return 'acf_post_widget';
}

public function get_title(){
return 'Post Title + ACF Field';
}

public function get_icon(){
return 'eicon-post-content';
}

public function get_categories(){
return ['general'];
}

protected function register_controls(){

/* CONTENT SECTION */

$this->start_controls_section(
'content_section',
[
'label'=>'Content',
'tab'=>\Elementor\Controls_Manager::TAB_CONTENT,
]
);

/* POST TYPE */

$post_types = get_post_types(['public'=>true],'names');

$this->add_control(
'post_type',
[
'label'=>'Post Type',
'type'=>\Elementor\Controls_Manager::SELECT,
'options'=>$post_types,
'default'=>'post',
]
);

/* NUMBER OF POSTS */

$this->add_control(
'post_count',
[
'label'=>'Posts Count',
'type'=>\Elementor\Controls_Manager::NUMBER,
'default'=>5,
]
);

/* ACF FIELD */

$this->add_control(
'acf_field',
[
'label'=>'ACF Field Name',
'type'=>\Elementor\Controls_Manager::TEXT,
'description'=>'Enter ACF field name',
]
);

$this->end_controls_section();


/* TITLE STYLE */

$this->start_controls_section(
'title_style',
[
'label'=>'Title Style',
'tab'=>\Elementor\Controls_Manager::TAB_STYLE,
]
);

$this->add_control(
'title_color',
[
'label'=>'Text Color',
'type'=>\Elementor\Controls_Manager::COLOR,
'selectors'=>[
'{{WRAPPER}} .aepw-title'=>'color: {{VALUE}}',
],
]
);

$this->add_group_control(
\Elementor\Group_Control_Typography::get_type(),
[
'name'=>'title_typography',
'selector'=>'{{WRAPPER}} .aepw-title',
]
);

$this->end_controls_section();


/* ACF STYLE */

$this->start_controls_section(
'acf_style',
[
'label'=>'ACF Field Style',
'tab'=>\Elementor\Controls_Manager::TAB_STYLE,
]
);

$this->add_control(
'acf_color',
[
'label'=>'Text Color',
'type'=>\Elementor\Controls_Manager::COLOR,
'selectors'=>[
'{{WRAPPER}} .aepw-acf'=>'color: {{VALUE}}',
],
]
);

$this->add_group_control(
\Elementor\Group_Control_Typography::get_type(),
[
'name'=>'acf_typography',
'selector'=>'{{WRAPPER}} .aepw-acf',
]
);

$this->end_controls_section();

}

/* RENDER */

protected function render(){

$settings = $this->get_settings_for_display();

$args = [
'post_type'=>$settings['post_type'],
'posts_per_page'=>$settings['post_count']
];

$query = new WP_Query($args);

if($query->have_posts()){

echo '<div class="aepw-wrapper">';

while($query->have_posts()){
$query->the_post();

echo '<div class="aepw-item">';

echo '<h3 class="aepw-title">'.get_the_title().'</h3>';

if(function_exists('get_field') && !empty($settings['acf_field'])){

$value = get_field($settings['acf_field']);

if($value){
echo '<div class="aepw-acf">'.$value.'</div>';
}

}

echo '</div>';

}

echo '</div>';

}

wp_reset_postdata();

}

}