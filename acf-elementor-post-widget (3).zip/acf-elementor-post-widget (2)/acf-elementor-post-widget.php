<?php
/**
 * Plugin Name: AFC Post Fields for Elementor
 * Plugin URI:  https://g.dev/fidatok
 * Description: Advanced Custom Field date with WordPress date fetched in Elementor Editor widgets.
 * Version:     1.2
 * Author:      ngital
 * Author URI:  https://ngital.com
 * License:     GPL2
 * Text Domain: afc_custom_post_Ngi
 */

if (!defined('ABSPATH')) {
    exit;
}

/* Register Elementor Widget */

function aepw_register_widgets($widgets_manager){

    require_once(__DIR__.'/widgets/acf-post-widget.php');

    $widgets_manager->register(new \AEPW_Post_Widget());

}

add_action('elementor/widgets/register','aepw_register_widgets');